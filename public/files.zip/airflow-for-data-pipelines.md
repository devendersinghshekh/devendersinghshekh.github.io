+++
title = 'Intro to Apache Airflow for Data Pipelines'
date = '2026-09-20T16:00:00+05:30'
draft = false
tags = ['airflow', 'orchestration', 'talk']
categories = ['Talks']
summary = 'A 30-minute campus talk on why orchestration matters and how to build your first reliable DAG.'
+++

| | |
|---|---|
| **Event** | University Tech Club Meetup (sample entry) |
| **Date** | 20 September 2026 |
| **Format** | 30 min talk + 10 min Q&A |
| **Audience** | Undergraduates, about 60 attendees |
| **Slides** | [Download PDF](#) |
| **Recording** | [Watch on YouTube](#) |

## Abstract

Cron jobs work until they don't. This talk covers what an orchestrator actually gives you (retries, dependencies, backfills, visibility) and walks through building a small ETL DAG from scratch.

## Outline

1. Why scripts + cron break down
2. Airflow core concepts: DAGs, tasks, operators, schedules
3. Live demo: a daily API-to-Postgres pipeline
4. Making DAGs reliable: idempotency, retries, sensors
5. Common pitfalls
6. Q&A

## Key takeaways

- Treat every task as **idempotent**: re-running must be safe.
- Keep DAG files light. Heavy work belongs in tasks, not at import time.
- Use **data-aware** scheduling instead of guessing arrival times.

## Demo snippet

```python
from airflow.decorators import dag, task
from datetime import datetime

@dag(schedule="@daily", start_date=datetime(2026, 9, 1), catchup=False)
def daily_api_to_postgres():
    @task(retries=3)
    def extract():
        ...

    @task
    def load(rows):
        ...

    load(extract())

daily_api_to_postgres()
```

## Questions I got

- *"Airflow or cron for a small project?"* Cron, until you need retries or dependencies.
- *"How do I test DAGs?"* Unit-test task functions, and add a DAG-import test in CI.
