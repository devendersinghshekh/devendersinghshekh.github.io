+++
title = 'Kafka Consumer Groups: Quick Notes'
date = '2026-11-10T20:15:00+05:30'
draft = false
tags = ['kafka', 'streaming', 'data-engineering']
categories = ['Notes']
summary = 'How consumer groups split partitions, what a rebalance really does, and the offset settings that bit me.'
+++

Short notes from working through Kafka consumer groups while building a streaming pipeline. Not a tutorial, just what I wish I had known earlier.

## The core idea

A **consumer group** is a set of consumers that share the work of reading a topic. Kafka assigns each **partition** to exactly **one** consumer in the group at a time.

```
Topic: orders (4 partitions)

Group A (3 consumers)          Group B (1 consumer)
  C1 -> P0, P1                   C1 -> P0, P1, P2, P3
  C2 -> P2
  C3 -> P3
```

Two consequences:

- More consumers than partitions means the extra consumers sit **idle**.
- Different groups read the topic **independently**, each with its own offsets.

## Rebalances

A rebalance happens when a consumer joins, leaves, or stops sending heartbeats. During a classic (eager) rebalance, **all** consumers stop, give up their partitions, and get new ones.

> Tip: use the cooperative sticky assignor to avoid stop-the-world rebalances.

```properties
partition.assignment.strategy=org.apache.kafka.clients.consumer.CooperativeStickyAssignor
session.timeout.ms=15000
max.poll.interval.ms=300000
```

## Offset settings that bit me

| Setting | What it does | My mistake |
|---|---|---|
| `auto.offset.reset=latest` | Where to start with no committed offset | Silently skipped old data on first run |
| `enable.auto.commit=true` | Commits offsets on a timer | Committed before processing finished |
| `max.poll.records` | Batch size per poll | Too high, so processing exceeded `max.poll.interval.ms` and caused a rebalance loop |

## Minimal Python consumer

```python
from confluent_kafka import Consumer

c = Consumer({
    "bootstrap.servers": "localhost:9092",
    "group.id": "orders-analytics",
    "auto.offset.reset": "earliest",
    "enable.auto.commit": False,
})
c.subscribe(["orders"])

try:
    while True:
        msg = c.poll(1.0)
        if msg is None or msg.error():
            continue
        process(msg.value())
        c.commit(msg)      # commit AFTER processing
finally:
    c.close()
```

## To revisit

- Exactly-once semantics with transactions
- Lag monitoring (Burrow vs. Prometheus exporter)
