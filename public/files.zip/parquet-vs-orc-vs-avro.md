+++
title = 'Parquet vs ORC vs Avro: A Small Benchmark'
date = '2026-08-30T12:00:00+05:30'
draft = false
tags = ['parquet', 'orc', 'avro', 'storage', 'benchmark']
categories = ['Research']
summary = 'Comparing file size and query time across three big-data file formats on a synthetic event dataset. Sample entry with illustrative numbers.'
+++

> **Note:** All numbers below are placeholder data for previewing the layout.

## Abstract

Columnar and row-based formats make different trade-offs. This study compares **Parquet**, **ORC**, and **Avro** on storage size, write time, and analytical query latency using a 50M-row synthetic clickstream dataset.

## Research question

> For analytics-heavy workloads on a data lake, which format gives the best balance of storage cost and query speed?

## Method

- **Dataset:** 50M rows, 18 columns (mix of strings, timestamps, ints)
- **Engine:** Spark 3.5 on a single 8-core machine
- **Compression:** Snappy for all formats
- **Queries:** full scan, single-column aggregation, filtered scan (selectivity about 1%)
- Each query run 5 times; median reported

## Results

| Format | Size (GB) | Write time (s) | Full scan (s) | Column agg (s) | Filtered scan (s) |
|---|---|---|---|---|---|
| Avro | 9.4 | 142 | 61 | 58 | 55 |
| Parquet | 3.8 | 118 | 44 | 7 | 9 |
| ORC | 3.5 | 131 | 46 | 6 | 8 |

## Discussion

- **Row vs. columnar:** Avro reads whole rows, so column aggregations gain nothing. Columnar formats skip unneeded columns.
- **Parquet vs. ORC:** Nearly tied. ORC was slightly smaller; Parquet has wider ecosystem support.
- **Where Avro still wins:** Streaming and schema evolution (for example Kafka messages), not analytics storage.

## Limitations

- Single machine, synthetic data
- No nested or wide-schema tests
- Cloud object storage latency not measured

## Future work

1. Repeat on S3 with partitioned data
2. Add Delta Lake and Iceberg table formats
3. Test schema evolution cost

## References

1. Apache Parquet documentation
2. Apache ORC specification
3. Apache Avro specification
