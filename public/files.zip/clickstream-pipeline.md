+++
title = 'Real-Time Clickstream Pipeline'
date = '2026-10-28T18:00:00+05:30'
draft = false
tags = ['kafka', 'spark', 'airflow', 'snowflake', 'docker']
categories = ['Projects']
summary = 'An end-to-end pipeline that ingests website click events, processes them in near real time, and serves analytics tables.'
+++

**Status:** In progress &nbsp;|&nbsp; **Repo:** [github.com/your-username/clickstream-pipeline](https://github.com/your-username)

## Overview

A hands-on project to practice production-style data engineering: streaming ingestion, batch backfills, orchestration, and a warehouse layer analysts can query.

## Architecture

```
Event generator --> Kafka --> Spark Structured Streaming --> S3 (Parquet)
                                                               |
                                              Airflow (hourly) v
                                                          Snowflake
                                                               |
                                                     dbt models / dashboards
```

## Stack

- **Ingestion:** Kafka (Docker Compose, 3 partitions)
- **Processing:** Spark Structured Streaming (PySpark)
- **Storage:** S3 with Parquet, partitioned by `event_date`
- **Orchestration:** Airflow
- **Warehouse:** Snowflake
- **Infra:** Docker, GitHub Actions for CI

## What works so far

- [x] Synthetic event generator (about 5k events/sec)
- [x] Kafka topics with schema validation
- [x] Streaming job with 1-minute windowed aggregations
- [x] Parquet sink with compaction
- [ ] Airflow DAG for hourly warehouse loads
- [ ] Data quality checks (Great Expectations)
- [ ] Dashboard

## Lessons learned

1. **Small files kill performance.** Streaming writes thousands of tiny Parquet files, so a compaction job is required.
2. **Late data is normal.** Watermarks need to match real arrival delays, not wishful thinking.
3. **Idempotent loads matter.** Every Airflow task should be safe to re-run.

## Next steps

Finish the Airflow DAG, add monitoring for consumer lag, and write a blog post on the compaction strategy.
